#include <stdio.h>
#include <stdlib.h>

int main(){

    int q;

    for (int i = 15; i <= 30; i++){
        q = i*i;
        printf("%d ", q);
    }
    return 0;
}
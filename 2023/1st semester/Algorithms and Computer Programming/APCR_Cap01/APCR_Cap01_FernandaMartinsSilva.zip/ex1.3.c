#include <stdio.h>
#include <stdlib.h>

int main(){

    printf("########\n#      #\n#      #\n#      #\n#      #\n########");
    
    return 0;
}


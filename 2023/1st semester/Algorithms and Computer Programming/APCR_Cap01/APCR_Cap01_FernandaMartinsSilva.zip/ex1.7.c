
#include <stdio.h>
#include <stdlib.h>


int main(){
    int  valorld,prmtro,area;
  

    printf("Valor do lado: ");
    scanf("%d",&valorld);


    prmtro = valorld*4;
    area = valorld*valorld;


    printf("Perimetro = %d\n",prmtro);
    printf("Area = %d",area);
    

    
    return 0;
}

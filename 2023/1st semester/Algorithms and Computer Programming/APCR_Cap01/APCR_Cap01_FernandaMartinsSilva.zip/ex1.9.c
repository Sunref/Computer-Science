#include <stdio.h>
#include <stdlib.h>


int main(){
    int  base,alt,area;


    printf("Valor do base: ");
    scanf("%d",&base);
    printf("Valor do altura: ");
    scanf("%d",&alt);



    area = (base*alt)/2;



    printf("Area = %d",area);
    

    
    return 0;
}

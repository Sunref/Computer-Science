#include <stdio.h>
#include <stdlib.h>


int main(){
    int  basema,baseme,alt,area;


    printf("Valor do base: ");
    scanf("%d",&basema);
    printf("Valor do base: ");
    scanf("%d",&baseme);
    printf("Valor do altura: ");
    scanf("%d",&alt);



    area = (basema+baseme)*alt/2;



    printf("Area = %d",area);
    

    
    return 0;
}

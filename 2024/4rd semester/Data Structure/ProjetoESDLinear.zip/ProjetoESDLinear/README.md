Esqueleto para desenvolvimento de simuladores simples para as estruturas de dados Pilha, Fila, Deque e Lista.

O simulador de pilha contém uma implementação básica de exemplo que pode ser utilizada para iniciar o desenvolvimento.

Prof. Dr. David Buzatto